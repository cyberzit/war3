using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: System.Reflection.AssemblyTitle("MongolRanger Client")]
[assembly: System.Reflection.AssemblyDescription("MongolRanger Warcraft III Online Platform & Live Crash Reconnect Client")]
[assembly: System.Reflection.AssemblyCompany("MongolRanger (mongolranger.com)")]
[assembly: System.Reflection.AssemblyProduct("MongolRanger Universal Client")]
[assembly: System.Reflection.AssemblyVersion("2.6.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("2.6.0.0")]

namespace MongolRanger
{
    public class MongolRangerForm : Form
    {
        private const string SERVER_URL = "https://mongolranger.com";
        private const string W3GS_HOST = "mongolranger.com";
        private int w3gsPort = 8051;
        private int localProxyPort = 6210;

        // Dark Theme Palette
        private static readonly Color BgRoot = Color.FromArgb(9, 12, 20);
        private static readonly Color BgSidebar = Color.FromArgb(14, 19, 31);
        private static readonly Color BgCard = Color.FromArgb(20, 27, 45);
        private static readonly Color BgInput = Color.FromArgb(12, 16, 28);
        private static readonly Color AccentPurple = Color.FromArgb(124, 58, 237);
        private static readonly Color AccentEmerald = Color.FromArgb(16, 185, 129);
        private static readonly Color AccentGold = Color.FromArgb(245, 158, 11);
        private static readonly Color AccentRed = Color.FromArgb(239, 68, 68);
        private static readonly Color TextWhite = Color.FromArgb(248, 250, 252);
        private static readonly Color TextMuted = Color.FromArgb(148, 163, 184);

        private string authToken = "";
        private string currentUsername = "";
        private string currentRoomId = "";
        private string currentRoomName = "";
        private string war3Dir = "";
        private string lastUploadedSha = "";
        private string lastDownloadedSha = "";
        private int currentPingMs = 0;
        private string roomFilter = "ALL";
        private byte[] currentLanAd = null;

        private TcpListener proxyListener = null;
        private UdpClient udpBroadcaster = null;
        private volatile bool running = true;

        // Auth Screen Controls
        private Panel authOverlay;
        private bool isRegisterMode = false;
        private Button btnTabSignIn;
        private Button btnTabSignUp;
        private TextBox txtUser;
        private TextBox txtPass;
        private Button btnSubmitAuth;
        private Label lblAuthStatus;

        // App Shell Controls
        private Panel appShell;
        private Label lblSidebarUser;
        private Label lblNetPing;
        private Button btnNavLobbies;
        private Button btnNavWarKey;
        private Button btnNavSettings;

        // Views
        private Panel viewLobbies;
        private Panel viewWarKey;
        private Panel viewSettings;

        // Lobbies View Controls
        private Label lblLobbyCount;
        private TextBox txtSearch;
        private Button btnFilterAll;
        private Button btnFilterWait;
        private Button btnFilterRun;
        private Panel createLobbyBar;
        private TextBox txtNewRoomName;
        private ComboBox cmbMaps;
        private ListView lvRooms;
        private Label lblActiveBanner;
        private TextBox txtStatusLog;

        // WarKey Controls
        private Button[] slotButtons = new Button[6];
        private string[] slotKeys = new string[] { "Alt+Q", "Alt+W", "Alt+A", "Alt+S", "Alt+Z", "Alt+X" };
        private int capturingSlot = -1;

        // Settings Controls
        private TextBox txtWar3Path;

        private List<Dictionary<string, string>> cachedMaps = new List<Dictionary<string, string>>();
        private List<Dictionary<string, string>> cachedRooms = new List<Dictionary<string, string>>();
        private System.Windows.Forms.Timer pollTimer;

        public MongolRangerForm()
        {
            try { ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072 | SecurityProtocolType.Tls; }
            catch { }

            this.Text = "MongolRanger v2.6 — Монголын Warcraft III & DotA Онлайн Платформ";
            this.Size = new Size(1060, 680);
            this.MinimumSize = new Size(980, 620);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = BgRoot;
            this.ForeColor = TextWhite;
            this.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);
            this.KeyPreview = true;
            this.KeyDown += MongolRangerForm_KeyDown;

            war3Dir = DetectWar3Directory();
            BuildAuthScreen();
            BuildAppShell();
            LoadSavedSettings();

            StartLocalBridge();
            MeasureServerPingAsync();

            pollTimer = new System.Windows.Forms.Timer();
            pollTimer.Interval = 3000;
            pollTimer.Tick += PollTimer_Tick;
            pollTimer.Start();

            this.Resize += (s, e) => CenterAuthCard();
            this.FormClosing += (s, e) =>
            {
                running = false;
                try { if (proxyListener != null) proxyListener.Stop(); } catch { }
                try { if (udpBroadcaster != null) udpBroadcaster.Close(); } catch { }
            };
        }

        private void CenterAuthCard()
        {
            if (authOverlay != null && authOverlay.Controls.Count > 0)
            {
                Control card = authOverlay.Controls[0];
                card.Location = new Point(Math.Max(20, (authOverlay.Width - card.Width) / 2), Math.Max(20, (authOverlay.Height - card.Height) / 2));
            }
        }

        private void BuildAuthScreen()
        {
            authOverlay = new Panel() { Dock = DockStyle.Fill, BackColor = BgRoot };

            Panel card = new Panel()
            {
                Size = new Size(420, 440),
                BackColor = BgSidebar,
                BorderStyle = BorderStyle.FixedSingle
            };

            Label lblLogo = new Label()
            {
                Text = "🛡️",
                Font = new Font("Segoe UI", 26f, FontStyle.Bold),
                ForeColor = AccentGold,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(0, 22),
                Size = new Size(420, 48)
            };

            Label lblBrand = new Label()
            {
                Text = "MongolRanger",
                Font = new Font("Segoe UI", 17f, FontStyle.Bold),
                ForeColor = TextWhite,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(0, 72),
                Size = new Size(420, 32)
            };

            Label lblWelcome = new Label()
            {
                Text = "Тавтай морилно уу! Нэвтрэх эсвэл шинээр бүртгүүлнэ үү.",
                Font = new Font("Segoe UI", 9f),
                ForeColor = TextMuted,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(20, 104),
                Size = new Size(380, 22)
            };

            // Toggle Tabs: Sign In / Sign Up
            btnTabSignIn = new Button()
            {
                Text = "Нэвтрэх (Sign In)",
                Location = new Point(40, 138),
                Size = new Size(168, 36),
                BackColor = AccentPurple,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold)
            };
            btnTabSignIn.FlatAppearance.BorderSize = 0;
            btnTabSignIn.Click += (s, e) => SetAuthMode(false);

            btnTabSignUp = new Button()
            {
                Text = "Бүртгүүлэх (Sign Up)",
                Location = new Point(212, 138),
                Size = new Size(168, 36),
                BackColor = BgCard,
                ForeColor = TextMuted,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold)
            };
            btnTabSignUp.FlatAppearance.BorderSize = 0;
            btnTabSignUp.Click += (s, e) => SetAuthMode(true);

            Label lU = new Label() { Text = "Тоглогчийн нэр (Username)", ForeColor = TextMuted, Location = new Point(40, 190), AutoSize = true };
            txtUser = new TextBox()
            {
                Location = new Point(40, 214),
                Width = 340,
                Font = new Font("Segoe UI", 11f),
                BackColor = BgInput,
                ForeColor = TextWhite,
                BorderStyle = BorderStyle.FixedSingle
            };

            Label lP = new Label() { Text = "Нууц үг (Хамгийн багадаа 10 тэмдэгт)", ForeColor = TextMuted, Location = new Point(40, 254), AutoSize = true };
            txtPass = new TextBox()
            {
                Location = new Point(40, 278),
                Width = 340,
                Font = new Font("Segoe UI", 11f),
                PasswordChar = '●',
                BackColor = BgInput,
                ForeColor = TextWhite,
                BorderStyle = BorderStyle.FixedSingle
            };
            txtPass.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) DoAuth(); };

            btnSubmitAuth = new Button()
            {
                Text = "Нэвтрэх  →",
                Location = new Point(40, 326),
                Size = new Size(340, 42),
                BackColor = AccentPurple,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10.5f, FontStyle.Bold)
            };
            btnSubmitAuth.FlatAppearance.BorderSize = 0;
            btnSubmitAuth.Click += (s, e) => DoAuth();

            lblAuthStatus = new Label()
            {
                Text = "",
                ForeColor = AccentGold,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(25, 378),
                Size = new Size(370, 48)
            };

            card.Controls.AddRange(new Control[] { lblLogo, lblBrand, lblWelcome, btnTabSignIn, btnTabSignUp, lU, txtUser, lP, txtPass, btnSubmitAuth, lblAuthStatus });
            authOverlay.Controls.Add(card);
            this.Controls.Add(authOverlay);
            CenterAuthCard();
        }

        private void SetAuthMode(bool register)
        {
            isRegisterMode = register;
            btnTabSignIn.BackColor = register ? BgCard : AccentPurple;
            btnTabSignIn.ForeColor = register ? TextMuted : Color.White;
            btnTabSignUp.BackColor = register ? AccentEmerald : BgCard;
            btnTabSignUp.ForeColor = register ? Color.Black : TextMuted;
            btnSubmitAuth.Text = register ? "Шинээр Бүртгүүлэх  →" : "Нэвтрэх  →";
            btnSubmitAuth.BackColor = register ? AccentEmerald : AccentPurple;
            btnSubmitAuth.ForeColor = register ? Color.Black : Color.White;
            lblAuthStatus.Text = "";
        }

        private void BuildAppShell()
        {
            appShell = new Panel() { Dock = DockStyle.Fill, BackColor = BgRoot, Visible = false };

            // 1. Left Navigation Sidebar
            Panel sidebar = new Panel() { Dock = DockStyle.Left, Width = 230, BackColor = BgSidebar };

            // Profile Box
            Panel profBox = new Panel() { Location = new Point(14, 16), Size = new Size(202, 68), BackColor = BgCard };
            lblSidebarUser = new Label()
            {
                Text = "🟢 ТОГЛОГЧ 🇲🇳",
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = TextWhite,
                Location = new Point(14, 12),
                AutoSize = true
            };
            Label lblSubRole = new Label()
            {
                Text = "MongolRanger Online",
                Font = new Font("Segoe UI", 8.5f),
                ForeColor = AccentEmerald,
                Location = new Point(14, 38),
                AutoSize = true
            };
            profBox.Controls.AddRange(new Control[] { lblSidebarUser, lblSubRole });

            // Nav Buttons
            btnNavLobbies = CreateNavButton("⚔️  Тоглоомын Өрөө", 104, true);
            btnNavLobbies.Click += (s, e) => SwitchMainView("LOBBIES");

            btnNavWarKey = CreateNavButton("⌨️  WarKey Тохиргоо", 152, false);
            btnNavWarKey.Click += (s, e) => SwitchMainView("WARKEY");

            btnNavSettings = CreateNavButton("⚙️  War3 Хавтас & Map", 200, false);
            btnNavSettings.Click += (s, e) => SwitchMainView("SETTINGS");

            Button btnQuickWar3 = new Button()
            {
                Text = "🎮 WARCRAFT III АСААХ",
                Location = new Point(14, 265),
                Size = new Size(202, 42),
                BackColor = AccentEmerald,
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold)
            };
            btnQuickWar3.FlatAppearance.BorderSize = 0;
            btnQuickWar3.Click += (s, e) => LaunchWarcraft();

            Button btnLogout = CreateNavButton("🚪  Гарах (Log Out)", 325, false);
            btnLogout.ForeColor = AccentRed;
            btnLogout.Click += (s, e) =>
            {
                LeaveRoom();
                authToken = "";
                appShell.Visible = false;
                authOverlay.Visible = true;
                CenterAuthCard();
            };

            // Bottom Network Diagnostics Card (like GameRanger X bottom-left card, showing our Direct W3GS status)
            Panel netCard = new Panel()
            {
                Location = new Point(14, 490),
                Size = new Size(202, 130),
                Anchor = AnchorStyles.Bottom | AnchorStyles.Left,
                BackColor = BgCard,
                BorderStyle = BorderStyle.FixedSingle
            };
            Label lNet1 = new Label() { Text = "СҮЛЖЭЭ (NETWORK)", Font = new Font("Segoe UI", 8f, FontStyle.Bold), ForeColor = TextMuted, Location = new Point(12, 10), AutoSize = true };
            Label lNet2 = new Label() { Text = "● Ready (Direct W3GS)", Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), ForeColor = AccentEmerald, Location = new Point(12, 28), AutoSize = true };
            Label lNet3 = new Label() { Text = "NAT:   Хаалтгүй (0% Алдаа)", Font = new Font("Segoe UI", 8.5f), ForeColor = TextWhite, Location = new Point(12, 52), AutoSize = true };
            lblNetPing = new Label() { Text = "PING:  ⚡ Хэмжиж байна...", Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), ForeColor = AccentGold, Location = new Point(12, 74), AutoSize = true };
            Label lNet4 = new Label() { Text = "PORT:  127.0.0.1:" + localProxyPort, Font = new Font("Segoe UI", 8f), ForeColor = TextMuted, Location = new Point(12, 98), AutoSize = true };
            netCard.Controls.AddRange(new Control[] { lNet1, lNet2, lNet3, lblNetPing, lNet4 });

            sidebar.Controls.AddRange(new Control[] { profBox, btnNavLobbies, btnNavWarKey, btnNavSettings, btnQuickWar3, btnLogout, netCard });

            // 2. Main Content Container
            Panel contentArea = new Panel() { Dock = DockStyle.Fill, BackColor = BgRoot };

            BuildLobbiesView();
            BuildWarKeyView();
            BuildSettingsView();

            contentArea.Controls.Add(viewLobbies);
            contentArea.Controls.Add(viewWarKey);
            contentArea.Controls.Add(viewSettings);

            appShell.Controls.Add(contentArea);
            appShell.Controls.Add(sidebar);
            this.Controls.Add(appShell);
        }

        private Button CreateNavButton(string text, int top, bool active)
        {
            Button b = new Button()
            {
                Text = text,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(12, 0, 0, 0),
                Location = new Point(14, top),
                Size = new Size(202, 40),
                BackColor = active ? AccentPurple : BgSidebar,
                ForeColor = active ? Color.White : TextMuted,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold)
            };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }

        private void SwitchMainView(string view)
        {
            viewLobbies.Visible = (view == "LOBBIES");
            viewWarKey.Visible = (view == "WARKEY");
            viewSettings.Visible = (view == "SETTINGS");

            btnNavLobbies.BackColor = (view == "LOBBIES") ? AccentPurple : BgSidebar;
            btnNavLobbies.ForeColor = (view == "LOBBIES") ? Color.White : TextMuted;

            btnNavWarKey.BackColor = (view == "WARKEY") ? AccentPurple : BgSidebar;
            btnNavWarKey.ForeColor = (view == "WARKEY") ? Color.White : TextMuted;

            btnNavSettings.BackColor = (view == "SETTINGS") ? AccentPurple : BgSidebar;
            btnNavSettings.ForeColor = (view == "SETTINGS") ? Color.White : TextMuted;
        }

        private void BuildLobbiesView()
        {
            viewLobbies = new Panel() { Dock = DockStyle.Fill, BackColor = BgRoot };

            Label lblHeading = new Label()
            {
                Text = "Lobbies (Тоглоомын Өрөөнүүд)",
                Font = new Font("Segoe UI", 18f, FontStyle.Bold),
                ForeColor = TextWhite,
                Location = new Point(24, 18),
                AutoSize = true
            };
            lblLobbyCount = new Label()
            {
                Text = "Нээлттэй өрөөнүүд",
                Font = new Font("Segoe UI", 9f),
                ForeColor = TextMuted,
                Location = new Point(26, 52),
                AutoSize = true
            };

            Button btnRefresh = new Button()
            {
                Text = "🔄 Шинэчлэх",
                Location = new Point(490, 22),
                Size = new Size(120, 36),
                BackColor = BgCard,
                ForeColor = TextWhite,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold)
            };
            btnRefresh.FlatAppearance.BorderSize = 0;
            btnRefresh.Click += (s, e) => { MeasureServerPingAsync(); RefreshMapsAndRooms(); };

            Button btnToggleCreate = new Button()
            {
                Text = "➕ Өрөө Үүсгэх (Create Lobby)",
                Location = new Point(620, 22),
                Size = new Size(185, 36),
                BackColor = AccentPurple,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold)
            };
            btnToggleCreate.FlatAppearance.BorderSize = 0;
            btnToggleCreate.Click += (s, e) => { createLobbyBar.Visible = !createLobbyBar.Visible; };

            // Search & Filter Bar
            txtSearch = new TextBox()
            {
                Text = "",
                Location = new Point(24, 82),
                Width = 340,
                Font = new Font("Segoe UI", 10f),
                BackColor = BgCard,
                ForeColor = TextWhite,
                BorderStyle = BorderStyle.FixedSingle
            };
            txtSearch.TextChanged += (s, e) => RenderRoomsList();

            Label lblSearchHint = new Label() { Text = "🔍 Хайх:", ForeColor = TextMuted, Location = new Point(374, 85), AutoSize = true };

            btnFilterAll = CreateFilterPill("Бүгд (All)", 440, true);
            btnFilterAll.Click += (s, e) => SetRoomFilter("ALL");

            btnFilterWait = CreateFilterPill("⏳ Хүлээж буй (Waiting)", 535, false);
            btnFilterWait.Click += (s, e) => SetRoomFilter("LOBBY");

            btnFilterRun = CreateFilterPill("⚔️ Тоглож буй (In Progress)", 685, false);
            btnFilterRun.Click += (s, e) => SetRoomFilter("RUNNING");

            // Create Lobby Bar (collapsible, visible by default so beginners see it immediately!)
            createLobbyBar = new Panel()
            {
                Location = new Point(24, 120),
                Size = new Size(780, 52),
                BackColor = BgCard,
                BorderStyle = BorderStyle.FixedSingle,
                Visible = true
            };
            Label lRN = new Label() { Text = "Өрөөний нэр:", ForeColor = TextMuted, Location = new Point(12, 16), AutoSize = true };
            txtNewRoomName = new TextBox()
            {
                Text = "Mongol DotA LoD",
                Location = new Point(102, 13),
                Width = 190,
                BackColor = BgInput,
                ForeColor = TextWhite,
                BorderStyle = BorderStyle.FixedSingle
            };
            Label lMp = new Label() { Text = "Map сонгох:", ForeColor = TextMuted, Location = new Point(304, 16), AutoSize = true };
            cmbMaps = new ComboBox()
            {
                Location = new Point(388, 12),
                Width = 220,
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = BgInput,
                ForeColor = TextWhite
            };
            Button btnConfirmCreate = new Button()
            {
                Text = "🚀 Өрөө Нээх (Host)",
                Location = new Point(620, 9),
                Size = new Size(148, 32),
                BackColor = AccentEmerald,
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold)
            };
            btnConfirmCreate.FlatAppearance.BorderSize = 0;
            btnConfirmCreate.Click += (s, e) => CreateRoom();
            createLobbyBar.Controls.AddRange(new Control[] { lRN, txtNewRoomName, lMp, cmbMaps, btnConfirmCreate });

            // Lobbies ListView Table
            lvRooms = new ListView()
            {
                Location = new Point(24, 182),
                Size = new Size(780, 240),
                View = View.Details,
                FullRowSelect = true,
                GridLines = false,
                BackColor = BgSidebar,
                ForeColor = TextWhite,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 10f)
            };
            lvRooms.Columns.Add("LOBBY (ӨРӨӨНИЙ НЭР)", 230);
            lvRooms.Columns.Add("MAP (ГАЗРЫН ЗУРАГ)", 185);
            lvRooms.Columns.Add("HOST (ЭЗЭН)", 125);
            lvRooms.Columns.Add("ТОГЛОГЧИД", 85);
            lvRooms.Columns.Add("PING", 70);
            lvRooms.Columns.Add("ТӨЛӨВ", 80);
            lvRooms.DoubleClick += (s, e) => JoinSelectedRoom();

            // Active Room Status Banner
            lblActiveBanner = new Label()
            {
                Text = "💡 Заавар: Жагсаалтаас өрөө сонгоод [1. Өрөөнд Орох] дарна уу, эсвэл дээрээс [Өрөө Нээх] дарж шинэ өрөө үүсгэнэ үү.",
                Location = new Point(24, 430),
                Size = new Size(780, 24),
                ForeColor = AccentEmerald,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold)
            };

            // Big Step-by-Step Action Buttons at Bottom
            Button btnJoin = new Button()
            {
                Text = "1️⃣  Сонгосон Өрөөнд Орох (Join)",
                Location = new Point(24, 460),
                Size = new Size(245, 42),
                BackColor = AccentPurple,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold)
            };
            btnJoin.FlatAppearance.BorderSize = 0;
            btnJoin.Click += (s, e) => JoinSelectedRoom();

            Button btnLaunch = new Button()
            {
                Text = "2️⃣  🎮 Warcraft III Асаах (LAN)",
                Location = new Point(280, 460),
                Size = new Size(245, 42),
                BackColor = AccentEmerald,
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold)
            };
            btnLaunch.FlatAppearance.BorderSize = 0;
            btnLaunch.Click += (s, e) => LaunchWarcraft();

            Button btnStart = new Button()
            {
                Text = "3️⃣  🚀 Тоглоом Эхлүүлэх (Start)",
                Location = new Point(536, 460),
                Size = new Size(180, 42),
                BackColor = AccentGold,
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold)
            };
            btnStart.FlatAppearance.BorderSize = 0;
            btnStart.Click += (s, e) => StartRoomMatch();

            Button btnLeave = new Button()
            {
                Text = "Гарах",
                Location = new Point(724, 460),
                Size = new Size(80, 42),
                BackColor = AccentRed,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold)
            };
            btnLeave.FlatAppearance.BorderSize = 0;
            btnLeave.Click += (s, e) => LeaveRoom();

            txtStatusLog = new TextBox()
            {
                Location = new Point(24, 512),
                Size = new Size(780, 105),
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical,
                BackColor = BgSidebar,
                ForeColor = TextMuted,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Consolas", 9f)
            };

            viewLobbies.Controls.AddRange(new Control[]
            {
                lblHeading, lblLobbyCount, btnRefresh, btnToggleCreate,
                txtSearch, lblSearchHint, btnFilterAll, btnFilterWait, btnFilterRun,
                createLobbyBar, lvRooms, lblActiveBanner,
                btnJoin, btnLaunch, btnStart, btnLeave, txtStatusLog
            });
        }

        private Button CreateFilterPill(string text, int left, bool active)
        {
            Button b = new Button()
            {
                Text = text,
                Location = new Point(left, 80),
                Size = new Size(left == 440 ? 90 : 145, 28),
                BackColor = active ? AccentPurple : BgCard,
                ForeColor = active ? Color.White : TextMuted,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold)
            };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }

        private void SetRoomFilter(string filter)
        {
            roomFilter = filter;
            btnFilterAll.BackColor = (filter == "ALL") ? AccentPurple : BgCard;
            btnFilterWait.BackColor = (filter == "LOBBY") ? AccentPurple : BgCard;
            btnFilterRun.BackColor = (filter == "RUNNING") ? AccentPurple : BgCard;
            RenderRoomsList();
        }

        private void BuildWarKeyView()
        {
            viewWarKey = new Panel() { Dock = DockStyle.Fill, BackColor = BgRoot, Visible = false };

            Label lTitle = new Label()
            {
                Text = "⌨️ Суурилагдсан WarKey (Баатарын 6 слот товч тохируулах)",
                Font = new Font("Segoe UI", 16f, FontStyle.Bold),
                Location = new Point(24, 22),
                AutoSize = true
            };
            Label lSub = new Label()
            {
                Text = "Доорх 6 нүдний аль нэг дээр хулганаар дараад, гар дээрээс хүссэн товчоо дарж онооно уу.\r\nТоглоом дотор Enter дарж чат бичих үед WarKey автоматаар түр зогсох тул чат бичихэд саад болохгүй.",
                ForeColor = TextMuted,
                Location = new Point(24, 58),
                Size = new Size(740, 44)
            };

            string[] slotNames = new string[]
            {
                "Slot 1 (Зүүн Дээд - Num 7)", "Slot 2 (Баруун Дээд - Num 8)",
                "Slot 3 (Зүүн Дунд - Num 4)", "Slot 4 (Баруун Дунд - Num 5)",
                "Slot 5 (Зүүн Доод - Num 1)", "Slot 6 (Баруун Доод - Num 2)"
            };

            for (int i = 0; i < 6; i++)
            {
                int idx = i;
                int col = i % 2;
                int row = i / 2;
                Panel box = new Panel()
                {
                    Location = new Point(24 + col * 270, 120 + row * 125),
                    Size = new Size(250, 108),
                    BackColor = BgCard,
                    BorderStyle = BorderStyle.FixedSingle
                };
                Label lSlot = new Label()
                {
                    Text = slotNames[i],
                    ForeColor = TextMuted,
                    Location = new Point(14, 12),
                    AutoSize = true
                };
                Button bKey = new Button()
                {
                    Text = slotKeys[i],
                    Location = new Point(14, 40),
                    Size = new Size(220, 50),
                    BackColor = BgInput,
                    ForeColor = AccentGold,
                    FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI", 13f, FontStyle.Bold)
                };
                bKey.Click += (s, e) =>
                {
                    capturingSlot = idx;
                    bKey.Text = "Товчоо дарна уу...";
                    bKey.ForeColor = AccentEmerald;
                };
                slotButtons[i] = bKey;
                box.Controls.AddRange(new Control[] { lSlot, bKey });
                viewWarKey.Controls.Add(box);
            }

            viewWarKey.Controls.AddRange(new Control[] { lTitle, lSub });
        }

        private void MongolRangerForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (capturingSlot >= 0 && capturingSlot < 6)
            {
                if (e.KeyCode == Keys.ControlKey || e.KeyCode == Keys.Menu || e.KeyCode == Keys.ShiftKey) return;
                string prefix = "";
                if (e.Alt) prefix = "Alt+";
                else if (e.Control) prefix = "Ctrl+";
                else if (e.Shift) prefix = "Shift+";
                string kName = prefix + e.KeyCode.ToString();
                slotKeys[capturingSlot] = kName;
                slotButtons[capturingSlot].Text = kName;
                slotButtons[capturingSlot].ForeColor = AccentGold;
                capturingSlot = -1;
                SaveSettings();
                e.SuppressKeyPress = true;
            }
        }

        private void BuildSettingsView()
        {
            viewSettings = new Panel() { Dock = DockStyle.Fill, BackColor = BgRoot, Visible = false };

            Label lTitle = new Label()
            {
                Text = "⚙️ Тохиргоо & Албан ёсны Map Татах",
                Font = new Font("Segoe UI", 16f, FontStyle.Bold),
                Location = new Point(24, 22),
                AutoSize = true
            };

            Panel box = new Panel()
            {
                Location = new Point(24, 70),
                Size = new Size(760, 220),
                BackColor = BgCard,
                BorderStyle = BorderStyle.FixedSingle
            };

            Label l1 = new Label() { Text = "Warcraft III 1.26a суусан хавтас:", Font = new Font("Segoe UI", 10.5f, FontStyle.Bold), Location = new Point(20, 20), AutoSize = true };
            txtWar3Path = new TextBox()
            {
                Text = war3Dir,
                Location = new Point(20, 50),
                Width = 560,
                Font = new Font("Segoe UI", 10.5f),
                BackColor = BgInput,
                ForeColor = TextWhite,
                BorderStyle = BorderStyle.FixedSingle
            };

            Button btnBrowse = new Button()
            {
                Text = "📁 Хавтас Сонгох...",
                Location = new Point(592, 48),
                Size = new Size(145, 30),
                BackColor = AccentPurple,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnBrowse.FlatAppearance.BorderSize = 0;
            btnBrowse.Click += (s, e) =>
            {
                using (FolderBrowserDialog fbd = new FolderBrowserDialog())
                {
                    if (fbd.ShowDialog() == DialogResult.OK)
                    {
                        war3Dir = fbd.SelectedPath;
                        txtWar3Path.Text = war3Dir;
                        SaveSettings();
                        Log("Warcraft III хавтас хадгалагдлаа: " + war3Dir);
                    }
                }
            };

            Label l2 = new Label()
            {
                Text = "Албан ёсны Map-ууд нь сервер дээр (-cam 1..2 болон Reconnect дэмжлэгтэйгээр) бэлэн хөрвүүлэгдсэн байгаа.\r\nТа өрөөнд ороход автоматаар татагдана, эсвэл доорх товчоор бүх Map-ийг нэг дор 2 секундэд татаж болно:",
                ForeColor = TextMuted,
                Location = new Point(20, 98),
                Size = new Size(710, 42)
            };

            Button btnDlAllMaps = new Button()
            {
                Text = "⬇️  Сервер дээрх Бүх Албан Ёсны Map-ийг Одоо Татах (2 сек)",
                Location = new Point(20, 150),
                Size = new Size(440, 44),
                BackColor = AccentEmerald,
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold)
            };
            btnDlAllMaps.FlatAppearance.BorderSize = 0;
            btnDlAllMaps.Click += (s, e) =>
            {
                SwitchMainView("LOBBIES");
                ThreadPool.QueueUserWorkItem(_ => DownloadAllCatalogMaps());
            };

            box.Controls.AddRange(new Control[] { l1, txtWar3Path, btnBrowse, l2, btnDlAllMaps });
            viewSettings.Controls.AddRange(new Control[] { lTitle, box });
        }

        private void MeasureServerPingAsync()
        {
            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    Stopwatch sw = Stopwatch.StartNew();
                    using (TcpClient tcp = new TcpClient())
                    {
                        IAsyncResult ar = tcp.BeginConnect(W3GS_HOST, w3gsPort, null, null);
                        if (ar.AsyncWaitHandle.WaitOne(3000))
                        {
                            tcp.EndConnect(ar);
                            sw.Stop();
                            currentPingMs = (int)Math.Max(1, sw.ElapsedMilliseconds);
                        }
                    }
                    this.BeginInvoke(new Action(() =>
                    {
                        lblNetPing.Text = "PING:  ⚡ " + currentPingMs + " ms (Direct)";
                    }));
                }
                catch { }
            });
        }

        private string GetConfigPath()
        {
            string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MongolRanger");
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
            return Path.Combine(dir, "client_config.txt");
        }

        private void LoadSavedSettings()
        {
            try
            {
                string cfg = GetConfigPath();
                if (File.Exists(cfg))
                {
                    foreach (string line in File.ReadAllLines(cfg, Encoding.UTF8))
                    {
                        int idx = line.IndexOf('=');
                        if (idx <= 0) continue;
                        string k = line.Substring(0, idx).Trim();
                        string v = line.Substring(idx + 1).Trim();
                        if (k == "username") txtUser.Text = v;
                        else if (k == "war3dir" && Directory.Exists(v))
                        {
                            war3Dir = v;
                            if (txtWar3Path != null) txtWar3Path.Text = v;
                        }
                    }
                }
            }
            catch { }
        }

        private void SaveSettings()
        {
            try
            {
                string content = "username=" + currentUsername + "\r\nwar3dir=" + war3Dir + "\r\n";
                File.WriteAllText(GetConfigPath(), content, Encoding.UTF8);
            }
            catch { }
        }

        private string DetectWar3Directory()
        {
            string[] candidates = new string[]
            {
                @"D:\Warcraft III",
                @"C:\Warcraft III",
                @"E:\Warcraft III",
                @"C:\Games\Warcraft III",
                @"D:\Games\Warcraft III",
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Warcraft III"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Warcraft III")
            };
            foreach (string c in candidates)
            {
                if (!string.IsNullOrEmpty(c) && (File.Exists(Path.Combine(c, "war3.exe")) || File.Exists(Path.Combine(c, "w3l.exe"))))
                    return c;
            }
            try
            {
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Software\Blizzard Entertainment\Warcraft III"))
                {
                    if (k != null)
                    {
                        object val = k.GetValue("InstallPath");
                        if (val != null && Directory.Exists(val.ToString())) return val.ToString();
                    }
                }
            }
            catch { }
            return @"C:\Warcraft III";
        }

        private void Log(string msg)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new Action<string>(Log), msg);
                return;
            }
            txtStatusLog.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] " + msg + "\r\n");
        }

        private string ApiRequest(string method, string path, string jsonBody = null)
        {
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(SERVER_URL + path);
            req.Method = method;
            req.Timeout = 10000;
            if (!string.IsNullOrEmpty(authToken))
                req.Headers["Authorization"] = "Bearer " + authToken;
            if (jsonBody != null)
            {
                byte[] data = Encoding.UTF8.GetBytes(jsonBody);
                req.ContentType = "application/json";
                req.ContentLength = data.Length;
                using (Stream s = req.GetRequestStream()) s.Write(data, 0, data.Length);
            }
            using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
            using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
            {
                return sr.ReadToEnd();
            }
        }

        private static string ExtractJsonString(string json, string key)
        {
            Match m = Regex.Match(json, "\"" + Regex.Escape(key) + "\"\\s*:\\s*\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"");
            return m.Success ? Regex.Unescape(m.Groups[1].Value) : "";
        }

        private static int ExtractJsonInt(string json, string key, int defVal = 0)
        {
            Match m = Regex.Match(json, "\"" + Regex.Escape(key) + "\"\\s*:\\s*(\\d+)");
            int v;
            return (m.Success && int.TryParse(m.Groups[1].Value, out v)) ? v : defVal;
        }

        private void DoAuth()
        {
            string u = txtUser.Text.Trim();
            string p = txtPass.Text;
            if (u.Length < 3 || p.Length < 10)
            {
                lblAuthStatus.Text = "Нэр 3+ тэмдэгт, нууц үг 10+ тэмдэгт байх ёстой!";
                return;
            }
            lblAuthStatus.Text = "Сервертэй холбогдож байна...";
            try
            {
                string body = "{\"username\":\"" + u.Replace("\"", "") + "\",\"password\":\"" + p.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"}";
                if (isRegisterMode)
                {
                    ApiRequest("POST", "/api/auth/register", body);
                }
                string res = ApiRequest("POST", "/api/auth/login", body);
                authToken = ExtractJsonString(res, "token");
                currentUsername = ExtractJsonString(res, "username");
                if (string.IsNullOrEmpty(currentUsername)) currentUsername = u;
                SaveSettings();
                SyncWar3Username(currentUsername);

                authOverlay.Visible = false;
                appShell.Visible = true;
                lblSidebarUser.Text = "🟢 " + currentUsername + " 🇲🇳";
                Log("Тавтай морил, " + currentUsername + "! Серверт амжилттай холбогдлоо.");
                MeasureServerPingAsync();
                RefreshMapsAndRooms();
            }
            catch (WebException wex)
            {
                string err = "Нэвтрэхэд алдаа гарлаа. Нэр эсвэл нууц үгээ шалгана уу.";
                try
                {
                    if (wex.Response != null)
                    {
                        using (StreamReader sr = new StreamReader(wex.Response.GetResponseStream()))
                            err = sr.ReadToEnd();
                    }
                }
                catch { }
                lblAuthStatus.Text = err;
            }
            catch (Exception ex)
            {
                lblAuthStatus.Text = ex.Message;
            }
        }

        private void SyncWar3Username(string name)
        {
            try
            {
                using (RegistryKey k = Registry.CurrentUser.CreateSubKey(@"Software\Blizzard Entertainment\Warcraft III\String"))
                {
                    if (k != null) k.SetValue("userlocal", name, RegistryValueKind.String);
                }
            }
            catch { }
        }

        private void RefreshMapsAndRooms()
        {
            if (string.IsNullOrEmpty(authToken)) return;
            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    string mapsJson = ApiRequest("GET", "/api/maps");
                    MatchCollection mm = Regex.Matches(mapsJson, "\\{[^{}]*\"filename\"\\s*:\\s*\"[^\"]+\"[^{}]*\\}");
                    List<Dictionary<string, string>> parsedMaps = new List<Dictionary<string, string>>();
                    foreach (Match m in mm)
                    {
                        string obj = m.Value;
                        Dictionary<string, string> d = new Dictionary<string, string>();
                        d["id"] = ExtractJsonString(obj, "id");
                        d["filename"] = ExtractJsonString(obj, "filename");
                        d["title"] = ExtractJsonString(obj, "title");
                        parsedMaps.Add(d);
                    }

                    string roomsJson = ApiRequest("GET", "/api/rooms");
                    MatchCollection rm = Regex.Matches(roomsJson, "\\{[^{}]*\"map_name\"\\s*:\\s*\"[^\"]+\"[^{}]*\\}");
                    List<Dictionary<string, string>> parsedRooms = new List<Dictionary<string, string>>();
                    foreach (Match m in rm)
                    {
                        string obj = m.Value;
                        Dictionary<string, string> d = new Dictionary<string, string>();
                        d["id"] = ExtractJsonString(obj, "id");
                        d["name"] = ExtractJsonString(obj, "name");
                        d["host"] = ExtractJsonString(obj, "host");
                        d["map_name"] = ExtractJsonString(obj, "map_name");
                        d["phase"] = ExtractJsonString(obj, "phase");
                        d["players"] = ExtractJsonInt(obj, "players", 1) + "/" + ExtractJsonInt(obj, "capacity", 10);
                        parsedRooms.Add(d);
                    }

                    this.BeginInvoke(new Action(() =>
                    {
                        if (cmbMaps.Items.Count != parsedMaps.Count && parsedMaps.Count > 0)
                        {
                            cachedMaps = parsedMaps;
                            cmbMaps.Items.Clear();
                            foreach (var m in parsedMaps) cmbMaps.Items.Add(m["title"]);
                            cmbMaps.SelectedIndex = 0;
                        }
                        cachedRooms = parsedRooms;
                        RenderRoomsList();
                    }));
                }
                catch { }
            });
        }

        private void RenderRoomsList()
        {
            string q = (txtSearch.Text ?? "").Trim().ToLowerInvariant();
            lvRooms.Items.Clear();
            int shown = 0;
            foreach (var r in cachedRooms)
            {
                if (roomFilter == "LOBBY" && r["phase"] != "LOBBY") continue;
                if (roomFilter == "RUNNING" && r["phase"] == "LOBBY") continue;
                if (!string.IsNullOrEmpty(q))
                {
                    string hay = (r["name"] + " " + r["host"] + " " + r["map_name"]).ToLowerInvariant();
                    if (!hay.Contains(q)) continue;
                }
                ListViewItem it = new ListViewItem("⚔️ " + r["name"]);
                it.Tag = r["id"];
                it.SubItems.Add(r["map_name"]);
                it.SubItems.Add("👑 " + r["host"] + " 🇲🇳");
                it.SubItems.Add("👥 " + r["players"]);
                it.SubItems.Add((currentPingMs > 0 ? currentPingMs.ToString() : "115") + " ms");
                it.SubItems.Add(r["phase"] == "LOBBY" ? "🟢 Waiting" : "🟠 In Progress");
                lvRooms.Items.Add(it);
                shown++;
            }
            lblLobbyCount.Text = shown + " of " + cachedRooms.Count + " өрөө харагдаж байна";
        }

        private void EnsureMapDownloaded(string mapId, string filename)
        {
            if (string.IsNullOrEmpty(filename)) return;
            war3Dir = txtWar3Path.Text.Trim();
            string dlDir = Path.Combine(war3Dir, "Maps", "Download");
            if (!Directory.Exists(dlDir)) Directory.CreateDirectory(dlDir);
            string dest = Path.Combine(dlDir, Path.GetFileName(filename));
            if (File.Exists(dest) && new FileInfo(dest).Length > 1024)
            {
                Log("Map бэлэн байна: " + filename);
                return;
            }
            Log("Серверээс '" + filename + "' map-ийг 2 секундэд татаж байна...");
            using (WebClient wc = new WebClient())
            {
                wc.DownloadFile(SERVER_URL + "/api/maps/" + Uri.EscapeDataString(string.IsNullOrEmpty(mapId) ? filename : mapId) + "/download", dest);
            }
            Log("✅ '" + filename + "' амжилттай татагдлаа!");
        }

        private void DownloadAllCatalogMaps()
        {
            try
            {
                foreach (var m in cachedMaps)
                {
                    EnsureMapDownloaded(m["id"], m["filename"]);
                }
                Log("✅ Сервер дээрх бүх албан ёсны Map татагдаж дууслаа!");
            }
            catch (Exception ex)
            {
                Log("Map татахад алдаа: " + ex.Message);
            }
        }

        private void CreateRoom()
        {
            string rname = txtNewRoomName.Text.Trim();
            if (string.IsNullOrEmpty(rname)) return;
            string mapFile = "LoD_Sync_25.w3x";
            if (cmbMaps.SelectedIndex >= 0 && cmbMaps.SelectedIndex < cachedMaps.Count)
                mapFile = cachedMaps[cmbMaps.SelectedIndex]["filename"];

            try
            {
                string body = "{\"name\":\"" + rname.Replace("\"", "") + "\",\"map_name\":\"" + mapFile.Replace("\"", "") + "\",\"capacity\":10}";
                string res = ApiRequest("POST", "/api/rooms", body);
                currentRoomId = ExtractJsonString(res, "room_id");
                currentRoomName = rname;
                w3gsPort = ExtractJsonInt(res, "w3gs_port", 8051);
                string lanHex = ExtractJsonString(res, "lan_ad_hex");
                if (!string.IsNullOrEmpty(lanHex)) currentLanAd = HexToBytes(lanHex);

                string mId = ExtractJsonString(res, "id");
                string mFn = ExtractJsonString(res, "filename");
                ThreadPool.QueueUserWorkItem(_ =>
                {
                    try { EnsureMapDownloaded(mId, string.IsNullOrEmpty(mFn) ? mapFile : mFn); } catch { }
                });

                lblActiveBanner.Text = "✅ ИДЭВХТЭЙ ӨРӨӨ (HOST): " + rname + " — Одоо [2. Warcraft III Асаах] дараад Local Area Network руу орно уу!";
                Log("Өрөө үүслээ: " + rname + ". Warcraft III -> Local Area Network дотор өрөө бэлэн харагдаж байна.");
                RefreshMapsAndRooms();
            }
            catch (Exception ex)
            {
                Log("Өрөө үүсгэхэд алдаа: " + ex.Message);
            }
        }

        private void JoinSelectedRoom()
        {
            if (lvRooms.SelectedItems.Count == 0)
            {
                MessageBox.Show("Жагсаалтаас орох өрөөгөө сонгоно уу!", "MongolRanger");
                return;
            }
            string rid = lvRooms.SelectedItems[0].Tag.ToString();
            string rname = lvRooms.SelectedItems[0].Text;
            try
            {
                string res = ApiRequest("POST", "/api/rooms/" + rid + "/join", "{}");
                currentRoomId = rid;
                currentRoomName = rname;
                w3gsPort = ExtractJsonInt(res, "w3gs_port", 8051);
                string lanHex = ExtractJsonString(res, "lan_ad_hex");
                if (!string.IsNullOrEmpty(lanHex)) currentLanAd = HexToBytes(lanHex);

                string mId = ExtractJsonString(res, "id");
                string mFn = ExtractJsonString(res, "filename");
                ThreadPool.QueueUserWorkItem(_ =>
                {
                    try { EnsureMapDownloaded(mId, mFn); } catch { }
                });

                lblActiveBanner.Text = "✅ НЭГДСЭН ӨРӨӨ: " + rname + " — Одоо [2. Warcraft III Асаах] дараад Local Area Network руу орно уу!";
                Log("'" + rname + "' өрөөнд нэгдлээ! Map шалгагдаж, LAN дотор өрөө цацагдаж эхэллээ.");
            }
            catch (Exception ex)
            {
                Log("Өрөөнд ороход алдаа: " + ex.Message);
            }
        }

        private void StartRoomMatch()
        {
            if (string.IsNullOrEmpty(currentRoomId)) return;
            try
            {
                ApiRequest("POST", "/api/rooms/" + currentRoomId + "/start", "{}");
                Log("🚀 Тоглоом эхлүүлэх команд илгээгдлээ!");
            }
            catch (Exception ex)
            {
                Log("Start алдаа: " + ex.Message);
            }
        }

        private void LeaveRoom()
        {
            if (string.IsNullOrEmpty(currentRoomId)) return;
            try { ApiRequest("POST", "/api/rooms/" + currentRoomId + "/leave", "{}"); } catch { }
            currentRoomId = "";
            currentLanAd = null;
            lblActiveBanner.Text = "Төлөв: Өрөөнөөс гарсан.";
            Log("Өрөөнөөс гарлаа.");
            RefreshMapsAndRooms();
        }

        private void LaunchWarcraft()
        {
            war3Dir = txtWar3Path.Text.Trim();
            SaveSettings();
            SyncWar3Username(currentUsername);
            string w3l = Path.Combine(war3Dir, "w3l.exe");
            string war3 = Path.Combine(war3Dir, "war3.exe");
            string exe = File.Exists(w3l) ? w3l : (File.Exists(war3) ? war3 : "");
            if (string.IsNullOrEmpty(exe))
            {
                SwitchMainView("SETTINGS");
                MessageBox.Show("Таны сонгосон хавтас дотор w3l.exe эсвэл war3.exe олдсонгүй!\n'War3 Хавтас' цэснээс тоглоом байгаа хавтсаа зааж өгнө үү.", "MongolRanger");
                return;
            }
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(exe, "-window");
                psi.WorkingDirectory = war3Dir;
                Process.Start(psi);
                Log("🎮 Warcraft III аслаа! Local Area Network цэс рүү орно уу.");
            }
            catch (Exception ex)
            {
                Log("Warcraft III асаахад алдаа: " + ex.Message);
            }
        }

        private void PollTimer_Tick(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(authToken)) return;
            RefreshMapsAndRooms();
            if (string.IsNullOrEmpty(currentRoomId)) return;

            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    try { ApiRequest("POST", "/api/rooms/" + currentRoomId + "/heartbeat", "{}"); } catch { }
                    string st = ApiRequest("GET", "/api/rooms/" + currentRoomId + "/state?local_port=" + localProxyPort);
                    string phase = ExtractJsonString(st, "phase");
                    string lanHex = ExtractJsonString(st, "lan_ad_hex");
                    if (!string.IsNullOrEmpty(lanHex)) currentLanAd = HexToBytes(lanHex);

                    CheckAndUploadCheckpoint();

                    Match cpMatch = Regex.Match(st, "\"checkpoint\"\\s*:\\s*\\{([^{}]+)\\}");
                    if (cpMatch.Success)
                    {
                        string cpObj = cpMatch.Groups[1].Value;
                        string cpSha = ExtractJsonString(cpObj, "sha256");
                        string cpFn = ExtractJsonString(cpObj, "filename");
                        if (!string.IsNullOrEmpty(cpSha) && cpSha != lastDownloadedSha && !string.IsNullOrEmpty(cpFn))
                        {
                            DownloadCheckpoint(cpFn, cpSha);
                        }
                    }

                    this.BeginInvoke(new Action(() =>
                    {
                        lblActiveBanner.Text = "🟢 ИДЭВХТЭЙ ӨРӨӨ: " + currentRoomName + "  |  Төлөв: " + phase + "  |  Warcraft III -> Local Area Network";
                    }));
                }
                catch { }
            });
        }

        private void CheckAndUploadCheckpoint()
        {
            try
            {
                string saveDir = Path.Combine(war3Dir, "Save", "Multiplayer");
                if (!Directory.Exists(saveDir)) return;
                FileInfo newest = null;
                foreach (string f in Directory.GetFiles(saveDir, "*.w3z"))
                {
                    FileInfo fi = new FileInfo(f);
                    if (fi.Length > 512 && (newest == null || fi.LastWriteTimeUtc > newest.LastWriteTimeUtc))
                        newest = fi;
                }
                if (newest == null || (DateTime.UtcNow - newest.LastWriteTimeUtc).TotalSeconds > 30) return;

                byte[] raw = File.ReadAllBytes(newest.FullName);
                string sha = ComputeSha256(raw);
                if (sha == lastUploadedSha || sha == lastDownloadedSha) return;
                lastUploadedSha = sha;

                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(SERVER_URL + "/api/rooms/" + currentRoomId + "/checkpoint");
                req.Method = "PUT";
                req.Headers["Authorization"] = "Bearer " + authToken;
                req.ContentType = "application/octet-stream";
                req.ContentLength = raw.Length;
                using (Stream s = req.GetRequestStream()) s.Write(raw, 0, raw.Length);
                using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse()) { }
                Log("💾 Crash-Reconnect Checkpoint серверт хадгалагдлаа (" + newest.Name + ")");
            }
            catch { }
        }

        private void DownloadCheckpoint(string filename, string sha)
        {
            try
            {
                string saveDir = Path.Combine(war3Dir, "Save", "Multiplayer");
                if (!Directory.Exists(saveDir)) Directory.CreateDirectory(saveDir);
                string dest = Path.Combine(saveDir, Path.GetFileName(filename));

                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(SERVER_URL + "/api/rooms/" + currentRoomId + "/checkpoint");
                req.Method = "GET";
                req.Headers["Authorization"] = "Bearer " + authToken;
                using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                using (Stream rs = resp.GetResponseStream())
                using (FileStream fs = new FileStream(dest, FileMode.Create, FileAccess.Write))
                {
                    rs.CopyTo(fs);
                }
                lastDownloadedSha = sha;
                Log("🔄 Сэргээх Checkpoint татагдлаа: " + filename + " — Local Area Network-оор шууд Rejoin хийнэ үү!");
            }
            catch { }
        }

        private void StartLocalBridge()
        {
            Thread proxyThread = new Thread(() =>
            {
                for (int p = 6210; p < 6225; p++)
                {
                    try
                    {
                        proxyListener = new TcpListener(IPAddress.Any, p);
                        proxyListener.Start();
                        localProxyPort = p;
                        break;
                    }
                    catch { }
                }
                while (running)
                {
                    try
                    {
                        TcpClient localClient = proxyListener.AcceptTcpClient();
                        ThreadPool.QueueUserWorkItem(_ => BridgeTcpSession(localClient));
                    }
                    catch { if (!running) break; }
                }
            });
            proxyThread.IsBackground = true;
            proxyThread.Start();

            Thread udpThread = new Thread(() =>
            {
                udpBroadcaster = new UdpClient();
                udpBroadcaster.EnableBroadcast = true;
                IPEndPoint epLocal = new IPEndPoint(IPAddress.Loopback, 6112);
                IPEndPoint epBcast = new IPEndPoint(IPAddress.Broadcast, 6112);
                while (running)
                {
                    try
                    {
                        byte[] pkt = currentLanAd;
                        if (pkt != null && pkt.Length > 0)
                        {
                            udpBroadcaster.Send(pkt, pkt.Length, epLocal);
                            try { udpBroadcaster.Send(pkt, pkt.Length, epBcast); } catch { }
                        }
                    }
                    catch { }
                    Thread.Sleep(1000);
                }
            });
            udpThread.IsBackground = true;
            udpThread.Start();
        }

        private void BridgeTcpSession(TcpClient localClient)
        {
            using (localClient)
            {
                try
                {
                    using (TcpClient remoteClient = new TcpClient(W3GS_HOST, w3gsPort))
                    {
                        localClient.NoDelay = true;
                        remoteClient.NoDelay = true;
                        Stream ls = localClient.GetStream();
                        Stream rs = remoteClient.GetStream();
                        Thread t1 = new Thread(() => { try { ls.CopyTo(rs); } catch { } });
                        t1.IsBackground = true;
                        t1.Start();
                        try { rs.CopyTo(ls); } catch { }
                    }
                }
                catch { }
            }
        }

        private static byte[] HexToBytes(string hex)
        {
            byte[] bytes = new byte[hex.Length / 2];
            for (int i = 0; i < bytes.Length; i++)
                bytes[i] = Convert.ToByte(hex.Substring(i * 2, 2), 16);
            return bytes;
        }

        private static string ComputeSha256(byte[] data)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(data);
                StringBuilder sb = new StringBuilder(hash.Length * 2);
                foreach (byte b in hash) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MongolRangerForm());
        }
    }
}
