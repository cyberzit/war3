#!/usr/bin/env python3
"""MongolRanger Universal Cross-Platform Client (macOS Apple Silicon / Intel & Windows)."""
import json
import os
from pathlib import Path
import socket
import ssl
import sys
import threading
import time
import urllib.parse
import urllib.request

SERVER_URL = os.environ.get("MONGOLRANGER_SERVER", "https://mongolranger.com")
W3GS_HOST = os.environ.get("MONGOLRANGER_W3GS_HOST", "mongolranger.com")
W3GS_PORT = int(os.environ.get("MONGOLRANGER_W3GS_PORT", "8051"))
LOCAL_PROXY_PORT = 6210

ssl_ctx = ssl.create_default_context()


def api_call(method: str, path: str, body: dict | None = None, token: str = "") -> dict:
    headers = {"Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(SERVER_URL + path, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=10, context=ssl_ctx) as resp:
        return json.loads(resp.read().decode("utf-8"))


def download_map_if_missing(war3_dir: Path, map_id: str, filename: str):
    if not filename:
        return
    dl_dir = war3_dir / "Maps" / "Download"
    dl_dir.mkdir(parents=True, exist_ok=True)
    dest = dl_dir / Path(filename).name
    if dest.is_file() and dest.stat().st_size > 1024:
        print(f"[✓] Map бэлэн байна: {dest}")
        return
    print(f"[⬇] Серверээс '{filename}' map-ийг 2 секундэд татаж байна...")
    url = f"{SERVER_URL}/api/maps/{urllib.parse.quote(map_id or filename)}/download"
    req = urllib.request.Request(url, method="GET")
    with urllib.request.urlopen(req, timeout=30, context=ssl_ctx) as resp:
        dest.write_bytes(resp.read())
    print(f"[✅] Амжилттай татагдлаа: {dest}")


def start_bridge(state: dict):
    def tcp_proxy():
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("0.0.0.0", LOCAL_PROXY_PORT))
        srv.listen(16)
        while state["running"]:
            try:
                client_sock, _ = srv.accept()
            except OSError:
                break
            threading.Thread(target=_pipe_pair, args=(client_sock, state["w3gs_port"]), daemon=True).start()

    def _pipe_pair(c_sock: socket.socket, r_port: int):
        try:
            r_sock = socket.create_connection((W3GS_HOST, r_port), timeout=10)
        except OSError:
            c_sock.close()
            return
        def fwd(src, dst):
            try:
                while True:
                    buf = src.recv(4096)
                    if not buf:
                        break
                    dst.sendall(buf)
            except OSError:
                pass
            finally:
                try:
                    dst.close()
                except OSError:
                    pass
        threading.Thread(target=fwd, args=(c_sock, r_sock), daemon=True).start()
        fwd(r_sock, c_sock)

    def udp_beacon():
        usock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        usock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        while state["running"]:
            ad_hex = state.get("lan_ad_hex", "")
            if ad_hex:
                pkt = bytes.fromhex(ad_hex)
                try:
                    usock.sendto(pkt, ("127.0.0.1", 6112))
                    usock.sendto(pkt, ("255.255.255.255", 6112))
                except OSError:
                    pass
            time.sleep(1.0)

    threading.Thread(target=tcp_proxy, daemon=True).start()
    threading.Thread(target=udp_beacon, daemon=True).start()


def main():
    print("==================================================================")
    print("  🛡️ MongolRanger Universal Client v2.6 (macOS & Windows)")
    print(f"  🌐 Сервер: {SERVER_URL} (W3GS Port {W3GS_PORT})")
    print("==================================================================")
    war3_default = Path.home() / "Games" / "Warcraft III"
    war3_in = input(f"Warcraft III хавтас [{war3_default}]: ").strip()
    war3_dir = Path(war3_in) if war3_in else war3_default

    mode = input("[1] Нэвтрэх  [2] Шинээр бүртгүүлэх (1/2) [1]: ").strip() or "1"
    username = input("Тоглогчийн нэр (3-24 тэмдэгт): ").strip()
    password = input("Нууц үг (10+ тэмдэгт): ").strip()
    if mode == "2":
        api_call("POST", "/api/auth/register", {"username": username, "password": password})
        print("[✓] Амжилттай бүртгэгдлээ!")
    auth = api_call("POST", "/api/auth/login", {"username": username, "password": password})
    token = auth["token"]
    print(f"[✓] Тавтай морил, {auth['username']}!")

    state = {"running": True, "w3gs_port": W3GS_PORT, "lan_ad_hex": ""}
    start_bridge(state)

    maps = api_call("GET", "/api/maps", token=token).get("maps", [])
    print("\n--- Сервер дээрх Албан ёсны Map-ууд ---")
    for idx, m in enumerate(maps, 1):
        print(f"  {idx}. {m['title']} ({m['filename']})")

    rooms = api_call("GET", "/api/rooms", token=token).get("rooms", [])
    print("\n--- Идэвхтэй Өрөөнүүд ---")
    for idx, r in enumerate(rooms, 1):
        print(f"  {idx}. {r['name']} | Host: {r['host']} | Map: {r['map_name']} ({r['players']}/{r['capacity']})")

    act = input("\n[H] Өрөө үүсгэх (Host)  [J] Өрөөнд орох (Join) [H/J]: ").strip().upper() or "H"
    if act == "J" and rooms:
        r_idx = int(input("Орох өрөөний дугаар [1]: ").strip() or "1") - 1
        rid = rooms[r_idx]["id"]
        res = api_call("POST", f"/api/rooms/{rid}/join", {}, token=token)
    else:
        rname = input("Шинэ өрөөний нэр [Mongol DotA LoD]: ").strip() or "Mongol DotA LoD"
        m_idx = int(input("Map дугаар [1]: ").strip() or "1") - 1
        m_file = maps[m_idx]["filename"] if maps else "LoD_Sync_25.w3x"
        res = api_call("POST", "/api/rooms", {"name": rname, "map_name": m_file, "capacity": 10}, token=token)
        rid = res["room_id"]

    state["w3gs_port"] = res.get("w3gs_port", W3GS_PORT)
    state["lan_ad_hex"] = res.get("lan_ad_hex", "")
    m_info = res.get("map", {})
    download_map_if_missing(war3_dir, m_info.get("id", ""), m_info.get("filename", ""))

    print("\n[🎮] Одоо Warcraft III -> Local Area Network цэс рүү орно уу! Өрөө шууд харагдана.")
    try:
        while True:
            cmd = input("[S = Тоглоом эхлүүлэх (Start) / Q = Гарах]: ").strip().upper()
            if cmd == "S":
                api_call("POST", f"/api/rooms/{rid}/start", {}, token=token)
                print("[🚀] Тоглоом эхэллээ!")
            elif cmd == "Q":
                break
    except KeyboardInterrupt:
        pass
    finally:
        state["running"] = False


if __name__ == "__main__":
    main()
