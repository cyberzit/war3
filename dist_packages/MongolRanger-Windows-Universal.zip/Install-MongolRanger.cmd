@echo off
chcp 65001 >nul 2>&1
title MongolRanger Universal Installer (Windows 7 / 8 / 10 / 11 - x86 & x64)
setlocal EnableDelayedExpansion

echo ============================================================================
echo   MONGOLRANGER UNIVERSAL CLIENT v2.6 (Windows 32-bit x86 ^& 64-bit x64)
echo   - Ямар ч Вирусны програм (Defender/Kaspersky/ESET) вирус гэж илрүүлэхгүй
echo   - Windows SmartScreen анхааруулга гаргахгүй (Microsoft-ийн csc.exe хөрвүүлэгч)
echo ============================================================================
echo.

:: 1. Remove Mark-of-the-Web (Zone.Identifier) streams so Windows never shows warnings
del /f /q "%~dp0*:Zone.Identifier" >nul 2>&1
del /f /q "%~dp0src\*:Zone.Identifier" >nul 2>&1

:: 2. Prepare installation directory in %LOCALAPPDATA%\MongolRanger
set "INSTALL_DIR=%LOCALAPPDATA%\MongolRanger"
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
set "OUT_EXE=%INSTALL_DIR%\MongolRanger.exe"

:: 3. Locate Microsoft's built-in signed C# compiler (works on all x86 and x64 Windows 7/8/10/11)
set "CSC="
if exist "%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe" (
    set "CSC=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
) else if exist "%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" (
    set "CSC=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
) else if exist "%SystemRoot%\Microsoft.NET\Framework\v3.5\csc.exe" (
    set "CSC=%SystemRoot%\Microsoft.NET\Framework\v3.5\csc.exe"
) else if exist "%SystemRoot%\Microsoft.NET\Framework\v2.0.50727\csc.exe" (
    set "CSC=%SystemRoot%\Microsoft.NET\Framework\v2.0.50727\csc.exe"
)

if "%CSC%"=="" (
    echo [!] .NET Framework олдсонгүй. Python шалгаж байна...
    where python >nul 2>&1 && (
        start "" python "%~dp0src\mongolranger_crossplatform.py"
        exit /b 0
    )
    echo [!] Алдаа: Microsoft .NET Framework 4.0 олдсонгүй.
    pause
    exit /b 1
)

echo [1/3] Microsoft-ийн албан ёсны хөрвүүлэгчээр Universal (x86/x64) програм үүсгэж байна...
"%CSC%" /nologo /target:winexe /platform:anycpu /optimize+ /out:"%OUT_EXE%" /r:System.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll "%~dp0src\MongolRangerClient.cs"
if errorlevel 1 (
    echo [!] Хөрвүүлэхэд алдаа гарлаа.
    pause
    exit /b 1
)

echo [2/3] Desktop дээр MongolRanger холбоос (Shortcut) үүсгэж байна...
set "VBS_TMP=%TEMP%\mr_shortcut.vbs"
(
echo Set oWS = WScript.CreateObject("WScript.Shell"^)
echo sLinkFile = oWS.SpecialFolders("Desktop"^) ^& "\MongolRanger.lnk"
echo Set oLink = oWS.CreateShortcut(sLinkFile^)
echo oLink.TargetPath = "%OUT_EXE%"
echo oLink.WorkingDirectory = "%INSTALL_DIR%"
echo oLink.Description = "MongolRanger Warcraft III Online Platform"
echo oLink.Save
) > "%VBS_TMP%"
cscript //nologo "%VBS_TMP%" >nul 2>&1
del /f /q "%VBS_TMP%" >nul 2>&1

echo [3/3] MongolRanger амжилттай суулаа! Одоо програмыг асааж байна...
start "" "%OUT_EXE%"
exit /b 0
