#!/usr/bin/env python3
"""MongolRanger Universal Cross-Platform Client (macOS Apple Silicon / Intel & Windows)."""
import json
import os
from pathlib import Path
import socket
import ssl
import threading
import time
import urllib.parse
import urllib.request

SERVER_URL = os.environ.get("MONGOLRANGER_SERVER", "https://mongolranger.com")
W3GS_HOST = os.environ.get("MONGOLRANGER_W3GS_HOST", "mongolranger.com")
W3GS_PORT = int(os.environ.get("MONGOLRANGER_W3GS_PORT", "8051"))
LOCAL_PROXY_PORT = 6210
ssl_ctx = ssl.create_default_context()


def api_call(method: str, path: str, body: dict | None = None, token: str = "") -> dict:
    headers = {"Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    data = json.dumps(body).encode("utf-8") if body is not None else None
    if data is not None:
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(SERVER_URL + path, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=10, context=ssl_ctx) as resp:
        return json.loads(resp.read().decode("utf-8"))


if __name__ == "__main__":
    print("MongolRanger macOS Client — https://mongolranger.com")
