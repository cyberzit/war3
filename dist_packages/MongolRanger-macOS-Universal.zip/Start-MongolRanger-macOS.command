#!/bin/bash
cd "$(dirname "$0")"
clear
python3 src/mongolranger_crossplatform.py
